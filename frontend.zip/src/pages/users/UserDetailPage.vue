<template>
    <div>
        UserDetailPage
    </div>
</template>