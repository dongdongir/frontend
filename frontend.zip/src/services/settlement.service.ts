export interface SettlementEntity {
  id: string;
}
