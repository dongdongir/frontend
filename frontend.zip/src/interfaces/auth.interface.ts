import { UserEntity } from "./user.interface";

interface Auth extends UserEntity {}
